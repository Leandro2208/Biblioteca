const botoes = document.querySelectorAll(.botoes);
console.log(botoes);

for (i=0; i<botoes.length; i++){
    console.log (i);
}
